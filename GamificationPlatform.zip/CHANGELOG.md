# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]
- Add secure project secret management:
  - `POST /v1/projects` returns `publicKey` and `plaintextSecret` only once
  - `POST /v1/projects/:id/rotate-secret` returns new `plaintextSecret` only once
  - Store only `secretKey` hash (`sha256`) server-side
- Emit audit events for project lifecycle:
  - `project.created` with payload `{ name, plan }`
  - `project.secret.rotated` with payload `{ publicKey }`
- Update documentation:
  - Root `README.md`: Project Secrets section with endpoints, events, and best practices
  - `docs/frontend/README.md`: Projetos + Eventos de Projeto with WS/Webhooks examples
  - `docs/REST.md` and `docs/API_HEADERS.md` already include examples and headers for project secrets
- Build validation: successful compile after integrating `EventsService` and fixing service class scope

## [0.1.0] - 2024-10-23
- Initial public structure of modules (projects, players, progression, etc.)
- Events pipeline (Mongo, WebSocket, Webhooks) and basic canonical types
- Admin/Client API Keys, Player Auth, and example REST/WS docs